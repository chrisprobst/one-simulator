#! /bin/sh
java -Xmx1500M -cp ./bin:lib/ECLA.jar:lib/DTNConsoleConnection.jar core.DTNSim $*